// babel.config.js
export default {
    presets: [
      '@babel/preset-env',  // Suporta o ES6+ moderno
      '@babel/preset-react' // Suporte ao JSX
    ]
  };
  