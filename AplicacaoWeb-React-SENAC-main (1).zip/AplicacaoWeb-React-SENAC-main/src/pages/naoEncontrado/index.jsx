import './index.scss'


export default function NaoEncontrado(){
    return (
        <div className='pagina-nãoEncontrada pagina' >
<h1>Pagina não Encontrada</h1>
        </div>
    )
}